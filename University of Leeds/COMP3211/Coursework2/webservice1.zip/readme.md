## Install Python

```
pip install flask
```

## Start CountyService
```
cd CountyService
python main.py
```

## Start AirportService
```
cd AirportService
python main.py
```

## Start the Client
```
cd Client
python view.py
```

## Test

goto the brower, then open the link:
http://127.0.0.1:8000/index